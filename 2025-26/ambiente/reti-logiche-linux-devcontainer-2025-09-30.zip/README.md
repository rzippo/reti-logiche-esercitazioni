# Ambiente Reti Logiche: esecuzione nativa o via devcontainer

Questo pacchetto supporta due scenari:
    - Esecuzione *nativa* su sistema Linux x64
        - Installare il software indicato nelle [dispense](https://rzippo.github.io/reti-logiche-esercitazioni/esercitazioni/Assembler/Ambiente).
    - Esecuzione via devcontainer
        - Compilare e riaprire nel devcontainer. [Documentazione](https://code.visualstudio.com/docs/devcontainers/containers).

In entrambi i casi non c'è un file `.code-workspace` dal lanciare, basta aprire la cartella (`assembler` o `verilog`) con VS Code.
