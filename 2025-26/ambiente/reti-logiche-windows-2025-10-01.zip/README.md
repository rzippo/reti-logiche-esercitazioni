# Ambiente Reti Logiche: Windows 11 e WSL2

Questo pacchetto supporta l'esecuzione su Windows 11 x64 con WSL2
    - L'ambiente assembler è virtualizzato tramite WSL2, ed è basato su Ubuntu 24.04
    - L'ambiente verilog è eseguito direttamente su Windows

I due ambienti hanno file `[linguaggio]-workspace.code-workspace` che aprono direttamente VS Code con la configurazione corretta.

## Installazione: assembler

- Installare Ubuntu 24.04 su WSL2
    - Aprire un terminale Powershell
    - Lanciare il comando `wsl --install Ubuntu-24.04 --name reti-logiche-assembler`
    - Avviare la distribuzione appena installata con `wsl --distribution reti-logiche-assembler`
        - Procedere con la configurazione iniziale dell'utente
    - Installare i pacchetti necessari
        - `sudo apt update; sudo apt upgrade -y;` 
        - `sudo apt install -y wget file build-essential gcc-multilib musl-dev gdb;`
        - `wget https://github.com/PowerShell/PowerShell/releases/download/v7.5.3/powershell_7.5.3-1.deb_amd64.deb`
        - `sudo dpkg -i powershell_7.5.3-1.deb_amd64.deb`
        - `sudo apt install -f`
        
## Installazione: verilog

- Installare [Icarus Verilog](https://bleyer.org/icarus/)
    - Spuntare la casella per aggiungere al PATH gli eseguibili installati
    - Se necessario aggiungerli manualmente, [qui](https://imatest.atlassian.net/wiki/spaces/KB/pages/12049809418/Editing+System+Environment+Variables) una delle tante guide a riguardo, le cartelle (default) sono `C:\iverilog\bin\` e `C:\iverilog\gtkwave\bin`